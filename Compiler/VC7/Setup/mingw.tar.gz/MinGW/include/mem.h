/*
 * This file is part of the Mingw32 package.
 *
 * mem.h maps to string.h
 */
#ifndef	__STRICT_ANSI__
#include <string.h>
#endif
