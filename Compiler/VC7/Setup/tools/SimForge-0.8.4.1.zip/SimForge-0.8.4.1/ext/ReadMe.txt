jep-2.4.1.jar is the Jep external library referring to Jep project.
The current version of Jep is not GPL, but the version we used for this project is.
Source code and other information about Jep version 2.4.1 can be found online on sourceforge website: http://sourceforge.net/projects/jep/

JMathTex-0.7pre.jar is the external library referring to XML project.
the version we used for this project is.
Source code and other information about JMathTex-0.7pre.jar can be found online on sourceforge website: http://sourceforge.net/projects/jmathtex