SITE PROPERTIES

Any property files (with extension .props) placed in this directory will
be loaded by jEdit before the user-specific properties. On multi-user
machines, this can be used to enforce a site-wide key binding or color
scheme, for example. Just copy the relevant entries from your user
properties file into a new .props file, and place it in this directory.
