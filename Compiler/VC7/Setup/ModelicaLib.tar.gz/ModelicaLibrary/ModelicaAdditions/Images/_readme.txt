This directory contains gif-pictures which are referenced in the
documentation of the ModelicaAdditions package.
